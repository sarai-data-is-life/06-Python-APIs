# OpenWeatherMap API Key
weather_api_key = "38f73c0a2a9fed0579060dd556962023"

# Google API Key
g_key = "AIzaSyCPGH_84EzOzgxWk5qjNdV0uTwTEOXm5mI"
